from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List, Optional
import uuid

app = FastAPI(title="CampusCore API - Pro Level Dashboard")

# --- IN-MEMORY DATABASE ---
departments_db = {}
students_db = {}

# --- NAYE MODELS (Aapke naye features ke sath) ---
class DepartmentModel(BaseModel):
    name: str
    room_number: str

# Ek naya model Subjects ke liye
class SubjectModel(BaseModel):
    subject_name: str
    subject_code: str

# Updated Student Model
class StudentModel(BaseModel):
    name: str
    roll_number: str
    department_id: str
    gpa: Optional[float] = 0.0                            # Naya Feature: GPA
    subjects: Optional[List[SubjectModel]] = []           # Naya Feature: Subjects List
    exam_schedule: Optional[str] = "Not Announced Yet"    # Naya Feature: Exams

# --- ROUTES (Same as before) ---
@app.get("/")
async def root():
    return {"status": "Server is running", "phase": "100% Pro Level"}

@app.post("/departments/")
async def create_department(dept: DepartmentModel):
    dept_id = str(uuid.uuid4()).replace("-", "")[:12]
    departments_db[dept_id] = dept.model_dump()
    return {"message": "Department created!", "id": dept_id}

@app.post("/students/")
async def create_student(student: StudentModel):
    student_id = str(uuid.uuid4()).replace("-", "")[:12]
    students_db[student_id] = student.model_dump()
    return {"message": "Student created!", "id": student_id}

@app.get("/students/")
async def get_all_students():
    return students_db

@app.get("/students/{student_id}")
async def get_single_student(student_id: str):
    if student_id not in students_db:
        raise HTTPException(status_code=404, detail="Student not found!")
    return students_db[student_id]

@app.put("/students/{student_id}")
async def update_student(student_id: str, updated_data: StudentModel):
    if student_id not in students_db:
        raise HTTPException(status_code=404, detail="Student not found!")
    
    students_db[student_id] = updated_data.model_dump()
    return {"message": "Student details updated successfully!"}

@app.delete("/students/{student_id}")
async def delete_student(student_id: str):
    if student_id not in students_db:
        raise HTTPException(status_code=404, detail="Student not found!")
    del students_db[student_id]
    return {"message": "Student deleted successfully!"}

@app.get("/departments/{dept_id}/students")
async def get_students_by_department(dept_id: str):
    dept_students = {s_id: s_data for s_id, s_data in students_db.items() if s_data["department_id"] == dept_id}
    if not dept_students:
        return {"message": "No students found in this department"}
    return dept_students