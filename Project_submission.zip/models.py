from pydantic import BaseModel

# Department ka structure
class DepartmentModel(BaseModel):
    name: str
    room_number: str

# Student ka structure (NAYA ADD HUA HAI)
class StudentModel(BaseModel):
    name: str
    roll_number: str
    department_id: str  # Yahan hum bata rahe hain ki ye kis department ka student hai (1:N Mapping)