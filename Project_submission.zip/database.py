from motor.motor_asyncio import AsyncIOMotorClient

# MongoDB Connection
client = AsyncIOMotorClient("mongodb://localhost:27017")
db = client.campuscore_db

# Collections (Tables)
department_collection = db.get_collection("departments")
student_collection = db.get_collection("students") # <-- YEH LINE MISSING THI!