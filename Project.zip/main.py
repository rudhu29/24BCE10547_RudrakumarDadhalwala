from fastapi import FastAPI
from pydantic import BaseModel
import uuid

# Title set kiya
app = FastAPI(title="CampusCore API - Project Dashboard")

# --- MODELS ---
class DepartmentModel(BaseModel):
    name: str
    room_number: str

class StudentModel(BaseModel):
    name: str
    roll_number: str
    department_id: str

# --- ROUTES ---
@app.get("/")
async def root():
    return {"status": "Server is running", "project": "CampusCore API"}

@app.post("/departments/")
async def add_department(dept: DepartmentModel):
    # MongoDB jaisi fake 24-character ID generate kar rahe hain
    fake_db_id = str(uuid.uuid4()).replace("-", "")[:24]
    return {"message": "Department successfully created!", "id": fake_db_id}

@app.post("/students/")
async def add_student(student: StudentModel):
    fake_db_id = str(uuid.uuid4()).replace("-", "")[:24]
    return {"message": "Student created and linked to department!", "id": fake_db_id}